package com.example.currencyconverter;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

public class JMDtoUSD extends AppCompatActivity {

		@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.activity_j_m_dto_u_s_d);

		}
}

