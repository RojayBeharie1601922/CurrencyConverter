package com.example.currencyconverter;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;

public class MainActivity extends AppCompatActivity {

		EditText userAmount;
		TextView resultView;
		Double conversionFactorJMDtoUSD = 0.0074;
		Double conversionFactorJMDtoEURO = 0.0068;
		Double conversionFactorJMDtoCAN = 0.010;
		Double conversionFactorUSDtoJMD = 135.82;
		Double conversionFactorUSDtoEURO = 0.92;
		Double conversionFactorUSDtoCAN = 1.42;
		Double conversionFactorEUROtoJMD = 147.72;
		Double conversionFactorEUROtoUSD = 1.09;
		Double conversionFactorEUROtoCAN = 1.55;
		Double conversionFactorCANtoJMD = 95.63;
		Double conversionFactorCANtoEURO = 0.65;
		Double conversionFactorCANtoUSD = 0.70;


		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.activity_main);

				Button jmdToUSD = (Button)findViewById(R.id.jmdToUSD);
				jmdToUSD.setOnClickListener(new View.OnClickListener() {
						@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
						@Override
						public void onClick(View v) {
								Intent i = new Intent(MainActivity.this, JMDtoUSD.class);
								startActivity(i);
						}
				});

				userAmount = findViewById(R.id.userAmount);
				resultView = findViewById(R.id.resultView);

		}

		public void ConvertJMDtoUSD(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double USD = userInput * conversionFactorJMDtoUSD;

				resultView.setText(Double.toString(USD));


		}

		public void ConvertJMDtoEURO(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double EURO = userInput * conversionFactorJMDtoEURO;

				resultView.setText(Double.toString(EURO));


		}

		public void ConvertJMDtoCAN(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double CAN = userInput * conversionFactorJMDtoCAN;

				resultView.setText(Double.toString(CAN));


		}

		public void ConvertUSDtoJMD(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double JMD = userInput * conversionFactorUSDtoJMD;

				resultView.setText(Double.toString(JMD));


		}

		public void ConvertUSDtoCAN(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double CAN = userInput * conversionFactorUSDtoCAN;

				resultView.setText(Double.toString(CAN));


		}

		public void ConvertUSDtoEURO(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double EURO = userInput * conversionFactorUSDtoEURO;

				resultView.setText(Double.toString(EURO));


		}

		public void ConvertEUROtoJMD(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double JMD = userInput * conversionFactorEUROtoJMD;

				resultView.setText(Double.toString(JMD));


		}

		public void ConvertEUROtoUSD(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double USD = userInput * conversionFactorEUROtoUSD;

				resultView.setText(Double.toString(USD));


		}

		public void ConvertEUROtoCAN(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double CAN = userInput * conversionFactorEUROtoCAN;

				resultView.setText(Double.toString(CAN));


		}

		public void ConvertCANtoJMD(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double JMD = userInput * conversionFactorCANtoJMD;

				resultView.setText(Double.toString(JMD));


		}

		public void ConvertCANtoUSD(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double USD = userInput * conversionFactorCANtoUSD;

				resultView.setText(Double.toString(USD));


		}

		public void ConvertCANtoEURO(View v){

				int userInput = Integer.parseInt(userAmount.getText().toString());

				double EURO = userInput * conversionFactorCANtoEURO;

				resultView.setText(Double.toString(EURO));


		}


}
